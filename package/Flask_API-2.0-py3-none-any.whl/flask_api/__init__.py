from flask_api.app import FlaskAPI

__version__ = '2.0'
